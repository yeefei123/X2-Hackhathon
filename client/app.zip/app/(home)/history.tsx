import React from "react";
import { SafeAreaView, View } from "react-native";

export default function History() {
  return (
    <SafeAreaView>
      <View></View>
    </SafeAreaView>
  );
}
